from .__meta__ import __author__, __version__
from .elastic import *

start_simul()